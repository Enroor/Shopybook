<?php
session_start();
require_once './templates/header.php';
?>

<?php require_once'./templates/footer.php'; ?>
