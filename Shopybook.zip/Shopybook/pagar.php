<?php
session_start();
unset($_SESSION["cart"]);
require_once './templates/header.php';
require_once './include/DB.php';

$nomUser = $_SESSION['usuario']; //nombre usuario
$user = DB::obtieneCliente($nomUser);
$idPedido = DB::obtienePedidosCliente($user->getid());
?>
<div id='compra-realizada'>
    <div>
        <h1>Compra realizada :)</h1>
        <h3>Tu número de pedido es: <?php echo substr(str_repeat(0, 9) . $idPedido[0]->getid(), - 9); ?></h3>
        <a href="index.php"><input type='submit' value='Seguir comprando' id='volver-tienda'/></a>
    </div>
</div>

<?php require_once './templates/footer.php'; ?>
