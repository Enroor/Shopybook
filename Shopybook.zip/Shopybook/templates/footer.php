</main>
<footer>
    <div>
        Shopybook 2022 ©
    </div>
</footer> 
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="js/btn-mostrar-form.js"></script>
<script type="text/javascript" src="js/btn-mostrar-form-categoria.js"></script>
<script type="text/javascript" src="js/confirmar-borrado.js"></script>
<script type="text/javascript" src="js/form-pago.js"></script>
<script type="text/javascript" src="js/perfil.js"></script>
</body>
</html>