<?php
define ('DB_DSN','mysql:host=localhost;dbname=shopybook');
define ('DB_USER','root');
define ('DB_PASSWD',''); 